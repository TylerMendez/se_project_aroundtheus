# Project 3: Around The U.S.

### Overview

- Intro
- Figma
- Images

**Intro**

This project is made so all the elements are displayed correctly on popular screen sizes. We recommend investing more time in completing this project, since it's more difficult than previous ones.

**Figma**

- [Link to the project on Figma](https://www.figma.com/file/ii4xxsJ0ghevUOcssTlHZv/Sprint-3%3A-Around-the-US?node-id=0%3A1)

**Images**

The way you'll do this at work is by exporting images directly from Figma — we recommend doing that to practice more. Don't forget to optimize them [here](https://tinypng.com/), so your project loads faster.

Good luck and have fun!

https://tylermendez.github.io/se_project_aroundtheus/

Project Name - Se_Project_aroundtheus.
Project description - This project consistent of an interactive page made for users to create a profile to upload photos and interact with the photos/content of other users by "liking" their photos/content.
Plans for improving the project include more features like more freedom to customize a profile. For example, uploading videos of short and long form. Follower count on the main profile page and like count on the content.
Interacting with the other pages with comments and direct messaging.

https://drive.google.com/file/d/1_FJQeRAOKuvEGufgklCYPr2asbPxD-oK/view?usp=sharing
